/*
 * CS106B Assignment 2 Part 1, WordLadder
 * Jian Zhong
*/
//
//  Created by Jian Zhong on 6/8/20.
//  Copyright © 2020 Jian Zhong. All rights reserved.
//

#include <cctype>
#include <cmath>
#include <fstream>
#include <iostream>
#include <string>
#include "console.h"
#include "lexicon.h"
#include "queue.h"
#include <unordered_set>
using namespace std;

void printGreetings();
void promptDictionary(fstream&, string&, Lexicon&);
void promptWords(string&, string&, bool&);
bool validFormat(const Lexicon&, const string&, const string&);
void printStack(Stack<string>);
void findWordLadder(const string&, const string&, const Lexicon&);

int main() {
    fstream inFile;
    string fileName, startWord, endWord;
    Lexicon dictionary;
    bool isReturn = false;

    printGreetings();
    promptDictionary(inFile, fileName, dictionary);
    promptWords(startWord, endWord, isReturn);
    while (!isReturn) {
        findWordLadder(startWord, endWord, dictionary);
        promptWords(startWord, endWord, isReturn);
    }

    cout << "Have a nice day!" << endl;
    return 0;
}


void printGreetings() {
    cout << "Welcome to CS 106B Word Ladder." << endl
         << "Please give me two English words, and I will change the" << endl
         << "first into the second by changing one letter at a time." << endl
         << endl;
}

void promptDictionary(fstream& inFile, string& fileName, Lexicon& dictionary) {
    while (true) {
        cout << "Dictionary file name? ";
        getline(cin, fileName);
        inFile.open(fileName);
        if (!inFile.fail()) break;
        cout << "Unable to open that file.  Try again." << endl;
    }
    dictionary.addWordsFromFile(inFile);
}

void promptWords(string& startWord, string& endWord, bool& returnKey) {
    cout << endl;
    cout << "Word #1 (or Enter to quit):";
    getline(cin, startWord);
    if (startWord.empty()) {
        returnKey = true;
        return;
    }

    cout << "Word #2 (or Enter to quit):";
    getline(cin, endWord);
    if (endWord.empty()) {
        returnKey = true;
        return;
    }
    startWord = toLowerCase(startWord);
    endWord = toLowerCase(endWord);
}

bool validFormat(const Lexicon& dictionary, const string& startWord, const string&  endWord) {
    if (!dictionary.contains(startWord) || !dictionary.contains(endWord)) {
        cout << "The two words must be found in the dictionary." << endl;
        return false;
    } else if (startWord.length() != endWord.length()) {
        cout << "The two words must be the same length." << endl;
        return false;
    } else if (startWord == endWord) {
        cout << "The two words must be different." << endl;
        return false;
    }
    return true;
}

void printStack(Stack<string> s) {
    while(!s.isEmpty()) {
        cout << s.pop();
        if (s.size() != 0) {
            cout << " -> ";
        }
    }
    cout << endl;
}

void findWordLadder(const string& startWord, const string& endWord, const Lexicon& dictionary) {
    // if invalid format, terminate this function
    if (!validFormat(dictionary, startWord, endWord)) return;

    // Solve Word Ladder begins:
    Queue< Stack<string> > ladders; // ladder combination
    Stack<string> ladder;           // each possible ladder
    Lexicon usedWords;              // used words collection

    ladder.push(startWord);   // add start word to ladder stack
    ladders.enqueue(ladder);  // add ladder stack to the ladders queue
    usedWords.add(startWord); // add start word to the used word collection

    // Search all the combination until a solution is found.
    // if combination is empty, then no ladder between both words.
    while (!ladders.isEmpty()) {
        Stack<string> currLadder = ladders.dequeue(); // take out a ladder stack for evaluation
        string currWord = currLadder.peek();          // take out a word on top of the ladder stack

        // Find all neighbors of the word above:
        // All neighbors but current word would be stored in a Lexicon named "neighbors"
        Lexicon neighbors;  // neighbor collection
        int size = currWord.size(); // word length
        for (int i = 0; i < size; i++) {
            for(char letter = 'a'; letter <= 'z'; letter++) {
                if (currWord[i] == letter) continue; // get rid of the same word
                string temp = currWord;  // 注意：这里一定要temp才行，不然word会变成其他字，就不是原来的word只变一个letter了。
                temp[i] = letter;
                if (dictionary.contains(temp) && !usedWords.contains(temp)) {
                    neighbors.add(temp);
                    usedWords.add(temp);
                }
            }
        }

        // If no neighbors, dequeue that combination in ladders queue.
        // Otherwise, check each neighbor:
        //    if meets the end word, solution found!
        //    if not, make a new ladder combination contains the neighbor,
        //            and add to the back of ladders queue,
        //            and search other possbilities at the same level.
        for (string neighbor : neighbors) {  // 注意：这里如果neighbor不存在就直接skip掉，回到开头while处dequeue掉该没有neighbor的组合。
            if (neighbor == endWord) {
                // solution found!
                currLadder.push(neighbor);
                cout << "A ladder from \"" << endWord << "\" to \"" << startWord << "\":" << endl;
                printStack(currLadder);
                return;
            } else {
                Stack<string> subLadder = currLadder;
                subLadder.push(neighbor);
                ladders.enqueue(subLadder);
            }
        }

    }
    cout << "No word ladder found from \"" << endWord << "\" back to \""
         << startWord << "\"." << endl;
}
