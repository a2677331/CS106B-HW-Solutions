# HW1_Life
# my CS106B Assignment1
